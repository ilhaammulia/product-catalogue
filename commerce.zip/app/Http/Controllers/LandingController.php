<?php

namespace App\Http\Controllers;

use Illuminate\Support\Str;
use Inertia\Inertia;
use App\Models\Product;

class LandingController extends Controller
{
    public function products()
    {
        return Inertia::render('Landing/Products');
    }

    public function product_detail()
    {
        $product = [
            'title' => 'Watch',
            'description' => '40mm 18K white gold case, screw-down crown with triplock triple waterproofness system, bidirectional rotatable 24-hour graduated bezel with blue and red Cerachrom insert and engraved numerals and graduations, scratch-resistant sapphire crystal with cyclops lens over the date and double anti-reflective coating, blue dial, Chromalight hour markers, Rolex calibre 3285 automatic movement with second time-zone hour hand and instantaneous date, approximately 70 hours of power reserve, white gold Oyster bracelet with flat three-piece links, folding Oysterlock buckle with Easylink 5mm comfort extension link. Waterproof to 100 meters. Baselworld 2019 release.',
            'price' => 2.321,
            'images' => [
                'https://flowbite.s3.amazonaws.com/docs/gallery/square/image-2.jpg',
                'https://flowbite.s3.amazonaws.com/docs/gallery/square/image-1.jpg',
                'https://flowbite.s3.amazonaws.com/docs/gallery/square/image-2.jpg',
                'https://flowbite.s3.amazonaws.com/docs/gallery/square/image-3.jpg',
                'https://flowbite.s3.amazonaws.com/docs/gallery/square/image-4.jpg',
                'https://flowbite.s3.amazonaws.com/docs/gallery/square/image-5.jpg',
            ]
        ];
        return Inertia::render('Product/Detail', [
            'product' => $product
        ]);
    }

    public function terms()
    {
        return Inertia::render('Landing/Terms');
    }

    public function about()
    {
        return Inertia::render('Landing/About');
    }

    public function contact()
    {
        return Inertia::render('Landing/Contact');
    }
}
