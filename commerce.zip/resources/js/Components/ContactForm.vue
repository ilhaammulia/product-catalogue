<template>
  <form class="">
    <div class="-mx-2 md:items-center md:flex">
      <div class="flex-1 px-2">
        <label class="block mb-2 text-sm text-gray-300">Full Name</label>
        <input type="text" placeholder="John Doe"
          class="block w-full px-5 py-3 mt-2 text-gray-300 bg-transparent border border-gold-600 rounded-md focus:border-gold-700 focus:ring-gold-700 focus:outline-none focus:ring focus:ring-opacity-40" />
      </div>

      <div class="flex-1 px-2 mt-4 md:mt-0">
        <label class="block mb-2 text-sm text-gray-300">Email address</label>
        <input type="email" placeholder="johndoe@example.com"
          class="block w-full px-5 py-3 mt-2 text-gray-300 bg-transparent border border-gold-600 rounded-md focus:border-gold-700 focus:ring-gold-700 focus:outline-none focus:ring focus:ring-opacity-40" />
      </div>
    </div>

    <div class="w-full mt-4">
      <label class="block mb-2 text-sm text-gray-300">Message</label>
      <textarea
        class="block w-full h-32 px-5 py-3 mt-2 text-gray-300 bg-transparent border border-gold-600 rounded-md md:h-56 focus:border-gold-700 focus:ring-gold-700 focus:outline-none focus:ring focus:ring-opacity-40"
        placeholder="Message"></textarea>
    </div>

    <button
      class="w-full px-6 py-3 mt-4 text-sm font-medium tracking-wide text-white capitalize transition-colors duration-300 transform bg-gold-600 rounded-md hover:bg-gold-700 focus:outline-none focus:ring focus:ring-gold-600 focus:ring-opacity-50">
    Submit
  </button>
</form></template>